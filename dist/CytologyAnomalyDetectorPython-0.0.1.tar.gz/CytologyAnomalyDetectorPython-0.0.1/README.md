# Cytology Anomaly Detector

Install with `pip install CitologyAnomalyDetector`.

Use it with:
```bash
anomaly-detection <path>
```

where <path> is the path to a folder with two subfolders train and valid. The train folder should contain at least one imagen, and the valid folder contain the images to analyse. 
